/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author eros-
 */
public class Pelicula {
    private String idPelicula;
    private String nombrePe;
    private String genero;
    private int duracion;
    private int stock;
    private int vecesArrendada;

    public Pelicula(String idPelicula, String nombrePe, String genero, int duracion, int stock) {
        this.idPelicula = idPelicula;
        this.nombrePe = nombrePe;
        this.genero = genero;
        this.duracion = duracion;
        this.stock = stock;
        this.vecesArrendada = 0;
    }

    public String getIdPelicula() {
        return idPelicula;
    }

    public String getNombrePe() {
        return nombrePe;
    }

    public String getGenero() {
        return genero;
    }

    public int getDuracion() {
        return duracion;
    }

    public int getStock() {
        return stock;
    }

    public int getVecesArrendada() {
        return vecesArrendada;
    }

    public void setIdPelicula(String idPelicula) {
        this.idPelicula = idPelicula;
    }

    public void setNombrePe(String nombrePe) {
        this.nombrePe = nombrePe;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setVecesArrendada(int vecesArrendada) {
        this.vecesArrendada = vecesArrendada;
    }

    public void aumentarVecesArrendada() {
        this.vecesArrendada++;
    }

    public boolean hayStock() {
        return stock > 0;
    }

    public void disminuirStock() {
        if (stock > 0) {
            stock--;
        }
    }

    public void aumentarStock() {
        stock++;
    }

    public String getTipoPelicula() {
        return "Pelicula general";
    }
    
    public class PeliculaEstreno extends Pelicula {
    private int anioEstreno;

    public PeliculaEstreno(String idPelicula, String nombrePe, String genero, int duracion, int stock, int anioEstreno) {
        super(idPelicula, nombrePe, genero, duracion, stock);
        this.anioEstreno = anioEstreno;
    }

    public int getAnioEstreno() {
        return anioEstreno;
    }

    public void setAnioEstreno(int anioEstreno) {
        this.anioEstreno = anioEstreno;
    }

    @Override
    public String getTipoPelicula() {
        return "Estreno";
    }

    @Override
    public String toString() {
        return "PeliculaEstreno{" +
                "id='" + getIdPelicula() + '\'' +
                ", nombre='" + getNombrePe() + '\'' +
                ", genero='" + getGenero() + '\'' +
                ", duracion=" + getDuracion() +
                ", stock=" + getStock() +
                ", vecesArrendada=" + getVecesArrendada() +
                ", anioEstreno=" + anioEstreno +
                ", tipo='" + getTipoPelicula() + '\'' +
                '}';
        }
    }

    public class PeliculaClasica extends Pelicula {
    private String decada;

    public PeliculaClasica(String idPelicula, String nombrePe, String genero, int duracion, int stock, String decada) {
        super(idPelicula, nombrePe, genero, duracion, stock);
        this.decada = decada;
    }

    public String getDecada() {
        return decada;
    }

    public void setDecada(String decada) {
        this.decada = decada;
    }

    @Override
    public String getTipoPelicula() {
        return "Clasica";
    }

    @Override
    public String toString() {
        return "PeliculaClasica{" +
                "id='" + getIdPelicula() + '\'' +
                ", nombre='" + getNombrePe() + '\'' +
                ", genero='" + getGenero() + '\'' +
                ", duracion=" + getDuracion() +
                ", stock=" + getStock() +
                ", vecesArrendada=" + getVecesArrendada() +
                ", decada='" + decada + '\'' +
                ", tipo='" + getTipoPelicula() + '\'' +
                '}';
        }
    }

    @Override
    public String toString() {
        return "Pelicula{" +
                "id='" + idPelicula + '\'' +
                ", nombre='" + nombrePe + '\'' +
                ", genero='" + genero + '\'' +
                ", duracion=" + duracion +
                ", stock=" + stock +
                ", vecesArrendada=" + vecesArrendada +
                ", tipo='" + getTipoPelicula() + '\'' +
                '}';
    }
}